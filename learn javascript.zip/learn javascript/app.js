// let b = 10

// for(i=0; i <= b; i++){
//     if(i%2 == 0){
//         document.write(i)
//     }
// }
function check() {
    console.log("ye hai javascript");
    fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => response.json())
        .then(data => {
            let userList = document.getElementById('listDiv');
            userList.innerHTML = ''; // Clear any existing content

            data.forEach(item => {
                let listItem = document.createElement('li');
                listItem.innerHTML = `<h2>${item.name}</h2>`;
                userList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}
