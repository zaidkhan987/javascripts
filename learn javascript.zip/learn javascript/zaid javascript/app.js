
var clean = ['karachi', 'islamabad','rawalpindi','lahore','hyderabads']
var cityTocheck = prompt('enter cleanest cities')

for (i = 2; i <= 4; i++){
    if(clean === cityTocheck[i]){
        alert('its one of thr cleanest')
    }
}